package Business;

public class SalarySlip {
   private int slipID;
   private int epfNumber;
   private int month;
   private int year;
   private double hourlyRate;
   private int hoursWorked;
   private double epf;
   private double tax;
   private double allowance;
   private double gSalary;
   private double netSalary;
   
   public SalarySlip() {
	// TODO Auto-generated constructor stub
   }
   
  
   
   public void setSlipID(int slipID) {
	this.slipID = slipID;
   }
   
   public int getSlipID() {
	return slipID;
   }
   
   public void setEpfNumber(int epfNumber) {
	this.epfNumber = epfNumber;
   }
   
   public int getEpfNumber() {
	return epfNumber;
   }
   
   public void setMonth(int month) {
	this.month = month;
   }
   
   public int getMonth() {
	return month;
   }
   
   public void setYear(int year) {
	this.year = year;
   }
   
   public int getYear() {
	return year;
   }
   
   public void setHourlyRate(double hourlyRate) {
	this.hourlyRate = hourlyRate;
   }
   
   public double getHourlyRate() {
	return hourlyRate;
  }
   
   public void setHoursWorked(int hoursWorked) {
	this.hoursWorked = hoursWorked;
  }
   
   public int getHoursWorked() {
	return hoursWorked;
   }
   
   public void setEpf(double epf) {
	this.epf = epf;
   }
   
   public double getEpf() {
	return epf;
  }
   
   public void setTax(double tax) {
	this.tax = tax;
  }
   
   public double getTax() {
	return tax;
   }
   
   public void setAllowance(double allowance) {
	this.allowance = allowance;
   }
   
   public double getAllowance() {
	return allowance;
   }
   
   public void setgSalary(double gSalary) {
	this.gSalary = gSalary;
  }
   
   public double getgSalary() {
	return gSalary;
  }
   
  public void setNetSalary(double netSalary) {
	this.netSalary = netSalary;
  }
  
  public double getNetSalary() {
	return netSalary;
 }
   
}