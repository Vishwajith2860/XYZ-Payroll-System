package Business;

import java.sql.Date;

public class Employee {
	private int epf;
	private String firstName;
	private String lastName;
	private String address;
	private String bank;
	private String accountno;
	private String salarytype;
	
	
	
	
	public Employee(int epf, String firstName, String lastName, String address, String bank, String accountno, String salarytype) {
		this.epf=epf;
		this.firstName=firstName;
		this.lastName=lastName;
		this.address=address;
		this.bank=bank;
		this.accountno=accountno;
		this.salarytype=salarytype;
	}
	
	
		// TODO Auto-generated constructor stub
	

	public void setEpfNumber(int epfNumber) {
		this.epf= epfNumber;
	}
	
	public int getEpfNumber() {
		return epf;
	}
	
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	public String getFirstName() {
		return firstName;
	}
	
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	public String getLastName() {
		return lastName;
	}
	
	public void setAddress(String address) {
		this.address = address;
	}
	
	public String getAddress() {
		return address;
	}
	
	public void setBank(String bank) {
		this.bank = bank;
	}
	
	public String getBank() {
		return bank;
	}
	
	public void setAccountNumber(String accountno) {
		this.accountno = accountno;
	}
	
	public String getAccountNumber() {
		return accountno;
	}
	
	public void setSalaryType(String salarytype) {
		this.salarytype = salarytype;
	}
	
	public String getSalaryType() {
		return salarytype;
	}

	public int getEmpID() {
		// TODO Auto-generated method stub
		return 0;
	}

	public Date getDob() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getGender() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getCountry() {
		// TODO Auto-generated method stub
		return null;
	}



	public int getEpfID() {
		// TODO Auto-generated method stub
		return 0;
	}
}


