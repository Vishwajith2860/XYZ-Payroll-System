package Business;

public class Project {
  private int projectID;
  private String title;
  private int duration;
  
  public Project() {
	// TODO Auto-generated constructor stub
  }
  
  public Project(int projectID, String title, int duration) {
	// TODO Auto-generated constructor stub
	  this.projectID=projectID;
	  this.title=title;
	  this.duration=duration;
  }
  
  public void setProjectID(int projectID) {
	this.projectID = projectID;
  }
  
  public int getProjectID() {
	return projectID;
  }
  
  public void setTitle(String title) {
	this.title = title;
  }
  
  public String getTitle() {
	return title;
  }
  
  public void setDuration(int duration) {
	this.duration = duration;
  }
  
  public int getDuration() {
	return duration;
}
}
