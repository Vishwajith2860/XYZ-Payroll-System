package Business;
import java.sql.Date;

public class Enroll {
	
	private int enrollID;
	private int employeeID;
	private int projectID;
	private Date enrollDate;
	
	public Enroll() {
		// TODO Auto-generated constructor stub
	}
	
	public Enroll(int enrollID, int employeeID, int projectID, Date enrollDate) {
		this.enrollID=enrollID;
		this.employeeID=employeeID;
		this.projectID=projectID;
		this.enrollDate=enrollDate;
	}
	
	public void setEnrollID(int enrollID) {
		this.enrollID = enrollID;
	}
	
	public int getEnrollID() {
		return enrollID;
	}
	
	public void setEmployeeID(int employeeID) {
		this.employeeID = employeeID;
	}
	
	public int getEmployeeID() {
		return employeeID;
	}
	
	public void setProjectID(int projectID) {
		this.projectID = projectID;
	}
	
	public int getProjectID() {
		return projectID;
	}
	
	public void setEnrollDate(Date enrollDate) {
		this.enrollDate = enrollDate;
	}
	
	public Date getEnrollDate() {
		return enrollDate;
	}

}
