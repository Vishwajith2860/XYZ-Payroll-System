package Data;
import java.util.ArrayList;

import Business.Employee;

public interface IData {
    boolean add(Employee emp);
    boolean delete(int epf);
    boolean update(Employee emp);
    Employee get(int epf);
    ArrayList<Employee> getAll();    
}
