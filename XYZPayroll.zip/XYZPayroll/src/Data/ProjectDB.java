package Data;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import Business.Project;

public class ProjectDB implements IProject{
	private Connection con;
	
	public ProjectDB() {
		try {
			//Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/empdb";
			String user = "root";
			String password = "";

			con = DriverManager.getConnection(url, user, password);
			if (con != null) {
				System.out.println("Database Connected successfully");
			} else {
				System.out.println("Database Connection failed");
			}
		  }catch(SQLException e) {
			  System.err.println(e.getMessage());
		  }
	}

	@Override
	public boolean add(Project p) {
		// TODO Auto-generated method stub
		String insert="insert into project(projectID, title, duration) values (?, ?, ?)";
		try {
			PreparedStatement ps=con.prepareStatement(insert);
			ps.setInt(1, p.getProjectID());
			ps.setString(2, p.getTitle());
			ps.setInt(3, p.getDuration());			
			int result=ps.executeUpdate();
			ps.close();
			if (result>0) {
				return true;
			}else {
				return false;
			}
		}catch(SQLException e) {
			System.err.println(e.getMessage());
			return false;
		}
		
	}

	@Override
	public boolean delete(int projectID) {
		// TODO Auto-generated method stub
		String delete="delete from project where projectID=?";
		try {
			PreparedStatement ps=con.prepareStatement(delete);
			ps.setInt(1, projectID);
			int result=ps.executeUpdate();
			if(result>0) {
				return true;
			}else {
				return false;
			}
			
		}catch(SQLException e) {
			System.err.println(e.getMessage());
			return false;
		}
	}

	@Override
	public boolean update(Project p) {
		// TODO Auto-generated method stub
		String update="update project set title=?, duration=? where projectID=?";
		try {
			PreparedStatement ps=con.prepareStatement(update);
			ps.setString(1, p.getTitle());
			ps.setInt(2, p.getDuration());			
			ps.setInt(3, p.getProjectID());
			int result=ps.executeUpdate();
			ps.close();
			if (result>0) {
				return true;
			}else {
				return false;
			}
			
		}catch(SQLException e) {
			System.err.println(e.getMessage());
			return false;
		}
	}

	@Override
	public Project get(int projectID) {
		// TODO Auto-generated method stub
		Project p=null;
		String select ="select * from project where projectID=?";
		try {
			PreparedStatement ps=con.prepareStatement(select);
			ps.setInt(1, projectID);
			ResultSet rs=ps.executeQuery();
			if(rs.next()) {
				//int projectID=rs.getInt("projectID");
				String title=rs.getString("title");
				int duration=rs.getInt("duration");
				p=new Project(projectID, title, duration);
			}
			rs.close();
			ps.close();
			return p;
		}catch(SQLException e) {
			System.err.println(e.getMessage());			
			return null;
		}
	}

	@Override
	public ArrayList<Project> getAll() {
		// TODO Auto-generated method stub
		ArrayList<Project> projectList=new ArrayList<Project>();
		String select="select * from project";
		try {
			PreparedStatement ps=con.prepareStatement(select);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				int projectID=rs.getInt("projectID");
				String title=rs.getString("title");
				int duration=rs.getInt("duration");
				Project p=new Project(projectID, title, duration);
				projectList.add(p);
			}
			rs.close();
			ps.close();
			return projectList;
		}catch(SQLException e) {
			System.err.println(e.getMessage());			
			return null;
		}
	}

}
