package Data;

import java.util.ArrayList;

import Business.Login;
import java.sql.*;

public class logDB implements ILogin{
	private Connection con;
	
	public logDB() {
		String url = "jdbc:mysql://localhost:3306/empdb";
		String user = "root";
		String password = "";
    try {
		con = DriverManager.getConnection(url, user, password);
		if (con != null) {
			System.out.println("Database Connected successfully");
		} else {
			System.out.println("Database Connection failed");
		}
	  }catch(SQLException e) {
		  System.err.println(e.getMessage());
	  }
	}

	@Override
	public boolean add(Login log) {
		// TODO Auto-generated method stub
		String insert="insert into login(userID, password) values(?,?)";
		try {
			PreparedStatement ps=con.prepareStatement(insert);
			ps.setString(1, log.getUserID());
			ps.setString(2, log.getPassword());
			int i=ps.executeUpdate();
			ps.close();
			if(i>0) {
				return true;
			}else {
				return false;
			}
		}catch(SQLException e) {
			System.err.println(e.getMessage());
			return false;
		}		
		
	}

	@Override
	public boolean delete(String userID) {
		// TODO Auto-generated method stub
		String delete="delete from login where userID=?";
		try {
			PreparedStatement ps=con.prepareStatement(delete);
			ps.setString(1, userID);
			int i=ps.executeUpdate();
			ps.close();
			if(i>0) {
				return true;
			}else {
				return false;
			}
		}catch(SQLException e) {
			System.err.println(e.getMessage());
			return false;
		}	
		
	}

	@Override
	public boolean update(Login log) {
		// TODO Auto-generated method stub
		String update="update login set password=? where userID=?";
		try {
			PreparedStatement ps=con.prepareStatement(update);
			ps.setString(1, log.getPassword());
			ps.setString(2, log.getUserID());
			int i=ps.executeUpdate();
			ps.close();
			if(i>0) {
				return true;
			}else {
				return false;
			}
		}catch(SQLException e) {
			System.err.println(e.getMessage());
			return false;
		}	
		
	}

	@Override
	public Login get(String userID) {
		Login log=null;
		String selet="select * from login where userID=?";
		try {
			PreparedStatement ps=con.prepareStatement(selet);
			ps.setString(1,userID);
			ResultSet rs=ps.executeQuery();
			if(rs.next()) {
				String password=rs.getString("password");
				log=new Login(userID, password);
			}
			rs.close();
			ps.close();
			return log;
		}catch(SQLException e) {
			System.err.println(e.getMessage());
			return null;
		}
		
	}

	@Override
	public ArrayList<Login> getAll() {
		// TODO Auto-generated method stub
		return null;
	}
	
	

}
