package Data;

import java.util.ArrayList;

import Business.Project;

public interface IProject {
	boolean add(Project p);
    boolean delete(int projectID);
    boolean update(Project p);
    Project get(int projectID);
    ArrayList<Project> getAll(); 
}
