package Data;

import java.util.ArrayList;

import Business.SalarySlip;

public interface ISalary {
	boolean add(SalarySlip slip);
    boolean delete(int sID);
    boolean update(SalarySlip slip);
    SalarySlip get(int sID);
    ArrayList<SalarySlip> getAll(); 
}
