package Data;

import java.sql.*;
import java.util.ArrayList;

import Business.Employee;

public class EmployeeDB implements IData{
	private Connection con;
	
	public EmployeeDB() {
		try {
			//Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/empdb";
			String user = "root";
			String password = "";

			con = DriverManager.getConnection(url, user, password);
			if (con != null) {
				System.out.println("Database Connected successfully");
			} else {
				System.out.println("Database Connection failed");
			}
		  }catch(SQLException e) {
			  System.err.println(e.getMessage());
		  }
	}

	@Override
	public boolean add(Employee emp) {
		// TODO Auto-generated method stub
		String insert="insert into employee(empID, epf, firstName, lastName, address, bank, accountno, salarytype) values (?, ?, ?, ?, ?, ?, ?,?)";
		try {
			PreparedStatement ps=con.prepareStatement(insert);
			ps.setInt(1, emp.getEmpID());
			ps.setInt(2, emp.getEpfNumber());
			ps.setString(3, emp.getFirstName());
			ps.setString(4, emp.getLastName());
			ps.setString(5, emp.getAddress());
			ps.setString(6, emp.getBank());
			ps.setString(7, emp.getAccountNumber());
			ps.setString(8, emp.getSalaryType());
			int result=ps.executeUpdate();
			ps.close();
			if (result>0) {
				return true;
			}else {
				return false;
			}
		}catch(SQLException e) {
			System.err.println(e.getMessage());
			return false;
		}
	}

	@Override
	public boolean delete(int epf) {
		// TODO Auto-generated method stub
		String delete="delete from employee where epf=?";
		try {
			PreparedStatement ps=con.prepareStatement(delete);
			ps.setInt(1, epf);
			int result=ps.executeUpdate();
			if(result>0) {
				return true;
			}else {
				return false;
			}
			
		}catch(SQLException e) {
			System.err.println(e.getMessage());
			return false;
		}
	}

	@Override
	public boolean update(Employee emp) {
		// TODO Auto-generated method stub
		String update="update employee set empID=?, epf=?, firstName=?, lastName=?, address=?,bank=?, accountno=?, salarytype=? where epf=?";
		try {
			PreparedStatement ps=con.prepareStatement(update);
			ps.setInt(1, emp.getEmpID());
			ps.setInt(2, emp.getEpfNumber());
			ps.setString(3, emp.getFirstName());
			ps.setString(4, emp.getLastName());
			ps.setString(5, emp.getAddress());
			ps.setString(6, emp.getBank());
			ps.setString(7, emp.getAccountNumber());
			ps.setString(8, emp.getSalaryType());
		
			int result=ps.executeUpdate();
			ps.close();
			if (result>0) {
				return true;
			}else {
				return false;
			}
			
		}catch(SQLException e) {
			System.err.println(e.getMessage());
			return false;
		}
	}

	@Override
	public Employee get(int epf) {
		// TODO Auto-generated method stub
		Employee emp=null;
		String select ="select * from employee where epf=?";
		try {
			PreparedStatement ps=con.prepareStatement(select);
			ps.setInt(1, epf);
			ResultSet rs=ps.executeQuery();
			if(rs.next()) {				
				String firstName=rs.getString("firstName");
				String lastName=rs.getString("lastName");
				String address=rs.getString("address");
				String bank=rs.getString("bank");
				String accountno=rs.getString("accountno");
				String salarytype=rs.getString("salarytype");
				emp=new Employee(epf, firstName, lastName, address, bank, accountno, salarytype);
			}
			rs.close();
			ps.close();
			return emp;
		}catch(SQLException e) {
			System.err.println(e.getMessage());			
			return null;
		}
		
	}

	@Override
	public ArrayList<Employee> getAll() {
		// TODO Auto-generated method stub
		ArrayList<Employee> empList=new ArrayList<Employee>();
		String select="select * from employee";
		try {
			PreparedStatement ps=con.prepareStatement(select);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				int epfNumber=rs.getInt("epf");
				String firstName=rs.getString("firstName");
				String lastName=rs.getString("lastName");
				String address=rs.getString("address");
				String bank=rs.getString("bank");
				String accountno=rs.getString("accountno");
				String salarytype=rs.getString("salarytype");
				Employee emp=new Employee(epfNumber, firstName, lastName, address, bank, accountno, salarytype);
				empList.add(emp);
			}
			rs.close();
			ps.close();
			return empList;
		}catch(SQLException e) {
			System.err.println(e.getMessage());			
			return null;
		}
		
	}
 

}
