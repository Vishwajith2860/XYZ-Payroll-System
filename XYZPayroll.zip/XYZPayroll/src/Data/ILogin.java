package Data;
import java.util.ArrayList;
import Business.Login;

public interface ILogin {
	boolean add(Login log);
    boolean delete(String userID);
    boolean update(Login log);
    Login get(String userID);
    ArrayList<Login> getAll();  
}
