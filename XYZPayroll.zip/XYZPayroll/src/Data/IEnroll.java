package Data;

import java.util.ArrayList;

import Business.Enroll;

public interface IEnroll {
	boolean add(Enroll p);
    boolean delete(int enrollID);
    boolean update(Enroll p);
    Enroll get(int enrollID);
    ArrayList<Enroll> getAll(); 
}
