package Data;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import Business.SalarySlip;

public class SalarySlipDB implements ISalary{
	private Connection con;
	
	public SalarySlipDB() {
		try {
			//Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/empdb";
			String user = "root";
			String password = "";

			con = DriverManager.getConnection(url, user, password);
			if (con != null) {
				System.out.println("Database Connected successfully");
			} else {
				System.out.println("Database Connection failed");
			}
		  }catch(SQLException e) {
			  System.err.println(e.getMessage());
		  }
	}
	
	@Override	
	public boolean add(SalarySlip slip) {
		// TODO Auto-generated method stub
		String insert="insert into salaryslip(salaryslipID,epfNumber, month, year, hourlyRate, hoursWorked, epf, tax,allowance,gSalary,netSalary) values (?, ?, ?, ?, ?, ?,?,?,?,?,?)";
		try {
			PreparedStatement ps=con.prepareStatement(insert);
			ps.setInt(1, slip.getSlipID());
			ps.setInt(2, slip.getEpfNumber());
			ps.setInt(3, slip.getMonth());
			ps.setInt(4, slip.getYear());
			ps.setDouble(5, slip.getHourlyRate());
			ps.setInt(6, slip.getHoursWorked());
			ps.setDouble(7, slip.getEpf());	
			ps.setDouble(8, slip.getTax());
			ps.setDouble(9, slip.getAllowance());
			ps.setDouble(10, slip.getgSalary());
			ps.setDouble(11, slip.getNetSalary());
			int result=ps.executeUpdate();			
			ps.close();
			if (result>0) {
				return true;
			}else {
				return false;
			}
		}catch(SQLException e) {
			System.err.println(e.getMessage());
			return false;
		}
	}

	@Override
	public boolean delete(int sID) {
		// TODO Auto-generated method stub
		String delete="delete from salaryslip where salaSlipID=?";
		try {
			PreparedStatement ps=con.prepareStatement(delete);
			ps.setInt(1, sID);
			int result=ps.executeUpdate();
			if(result>0) {
				return true;
			}else {
				return false;
			}
			
		}catch(SQLException e) {
			System.err.println(e.getMessage());
			return false;
		}
	}

	@Override
	public boolean update(SalarySlip slip) {
		// TODO Auto-generated method stub
		String update="update salaryslip set epfNumber=?, month=?, year=?,hourlyRate=?,hoursWorked=?, epf=?, tax=?, allowance=?,gSalary=?, netSalary=? where salarySlipID=?";
		try {
			PreparedStatement ps=con.prepareStatement(update);			
			ps.setInt(1, slip.getEpfNumber());
			ps.setInt(2, slip.getMonth());
			ps.setInt(3, slip.getYear());
			ps.setDouble(4, slip.getHourlyRate());
			ps.setInt(5, slip.getHoursWorked());
			ps.setDouble(6, slip.getEpf());	
			ps.setDouble(7, slip.getTax());
			ps.setDouble(8, slip.getAllowance());
			ps.setDouble(9, slip.getgSalary());
			ps.setDouble(10, slip.getNetSalary());
			ps.setInt(11, slip.getSlipID());
			int result=ps.executeUpdate();
			ps.close();
			if (result>0) {
				return true;
			}else {
				return false;
			}
			
		}catch(SQLException e) {
			System.err.println(e.getMessage());
			return false;
		}
	}

	@Override
	public SalarySlip get(int sID) {
		// TODO Auto-generated method stub
		SalarySlip ss=null;
		String select ="select * from salaryslip where salarySlipID=?";
		try {
			PreparedStatement ps=con.prepareStatement(select);
			ps.setInt(1, sID);
			ResultSet rs=ps.executeQuery();
			if(rs.next()) {				
				int epfNumber=rs.getInt("epfNumber");
				int month=rs.getInt("month");
				int year=rs.getInt("year");
				double hourlyRate=rs.getDouble("hourlyRate");
				int hoursWorked=rs.getInt("hoursWorked");
				double epf=rs.getDouble("epf");
				double tax=rs.getDouble("tax");
				double allowance=rs.getDouble("allowance");
				double gSalary=rs.getDouble("gSalary");
				double netSalary=rs.getDouble("netSalary");
				
				ss=new SalarySlip();
				
				ss.setSlipID(sID);
				ss.setEpfNumber(epfNumber);
				ss.setMonth(month);
				ss.setYear(year);
				ss.setHourlyRate(hourlyRate);
				ss.setHoursWorked(hoursWorked);
				ss.setEpf(epf);
				ss.setTax(tax);
				ss.setAllowance(allowance);
				ss.setgSalary(gSalary);
				ss.setNetSalary(netSalary);
				
			}
			rs.close();
			ps.close();
			return ss;
		}catch(SQLException e) {
			System.err.println(e.getMessage());			
			return null;
		}
	}

	@Override
	public ArrayList<SalarySlip> getAll() {
		// TODO Auto-generated method stub
		ArrayList<SalarySlip> sList=new ArrayList<SalarySlip>();
		String select="select * from salaryslip";
		try {
			PreparedStatement ps=con.prepareStatement(select);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				int sID=rs.getInt("salarySlipID");
				int epfNumber=rs.getInt("epfNumber");
				int month=rs.getInt("month");
				int year=rs.getInt("year");
				double hourlyRate=rs.getDouble("hourlyRate");
				int hoursWorked=rs.getInt("hoursWorked");
				double epf=rs.getDouble("epf");
				double tax=rs.getDouble("tax");
				double allowance=rs.getDouble("allowance");
				double gSalary=rs.getDouble("gSalary");
				double netSalary=rs.getDouble("netSalary");
				
				SalarySlip ss=new SalarySlip();
				ss.setSlipID(sID);
				ss.setEpfNumber(epfNumber);
				ss.setMonth(month);
				ss.setYear(year);
				ss.setHourlyRate(hourlyRate);
				ss.setHoursWorked(hoursWorked);
				ss.setEpf(epf);
				ss.setTax(tax);
				ss.setAllowance(allowance);
				ss.setgSalary(gSalary);
				ss.setNetSalary(netSalary);
				sList.add(ss);
			}
			rs.close();
			ps.close();
			return sList;
		}catch(SQLException e) {
			System.err.println(e.getMessage());			
			return null;
		}
		
	}

}