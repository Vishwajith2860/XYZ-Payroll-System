package Data;

import java.util.ArrayList;

import Business.Enroll;
import Business.Project;

import java.sql.*;

public class EnrollDB implements IEnroll{
	private Connection con;

	public EnrollDB() {
		try {
			//Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/empdb";
			String user = "root";
			String password = "";

			con = DriverManager.getConnection(url, user, password);
			if (con != null) {
				System.out.println("Database Connected successfully");
			} else {
				System.out.println("Database Connection failed");
			}
		  }catch(SQLException e) {
			  System.err.println(e.getMessage());
		  }
	}
	
	
	@Override
	public boolean add(Enroll p) {
		// TODO Auto-generated method stub
		String insert="insert into enroll(enrollID, employeeID,projectID, enrollDate) values (?, ?, ?,?)";
		try {
			PreparedStatement ps=con.prepareStatement(insert);
			ps.setInt(1, p.getEnrollID());
			ps.setInt(2, p.getEmployeeID());
			ps.setInt(3, p.getProjectID());	
			ps.setDate(4, p.getEnrollDate());
			int result=ps.executeUpdate();
			ps.close();
			if (result>0) {
				return true;
			}else {
				return false;
			}
		}catch(SQLException e) {
			System.err.println(e.getMessage());
			return false;
		}
	}

	@Override
	public boolean delete(int enrollID) {
		// TODO Auto-generated method stub
		String delete="delete from enroll where enrollID=?";
		try {
			PreparedStatement ps=con.prepareStatement(delete);
			ps.setInt(1, enrollID);
			int result=ps.executeUpdate();
			if(result>0) {
				return true;
			}else {
				return false;
			}
			
		}catch(SQLException e) {
			System.err.println(e.getMessage());
			return false;
		}
	}

	@Override
	public boolean update(Enroll p) {
		// TODO Auto-generated method stub
		String update="update enroll set empoyeeID=?, projectID=?, enrollDate=? where enrollID=?";
		try {
			PreparedStatement ps=con.prepareStatement(update);
			ps.setInt(1, p.getEmployeeID());
			ps.setInt(2, p.getProjectID());	
			ps.setDate(3, p.getEnrollDate());
			ps.setInt(4, p.getEnrollID());
			int result=ps.executeUpdate();
			ps.close();
			if (result>0) {
				return true;
			}else {
				return false;
			}
			
		}catch(SQLException e) {
			System.err.println(e.getMessage());
			return false;
		}
	}

	@Override
	public Enroll get(int enrollID) {
		// TODO Auto-generated method stub
		Enroll p=null;
		String select ="select * from enroll where enrollID=?";
		try {
			PreparedStatement ps=con.prepareStatement(select);
			ps.setInt(1, enrollID);
			ResultSet rs=ps.executeQuery();
			if(rs.next()) {				
				int employeeID=rs.getInt("employeeID");
				int projectID=rs.getInt("projectID");
				Date enrollDate=rs.getDate("enrollDate");
				p=new Enroll(enrollID, employeeID, projectID, enrollDate);
			}
			rs.close();
			ps.close();
			return p;
		}catch(SQLException e) {
			System.err.println(e.getMessage());			
			return null;
		}
	}

	@Override
	public ArrayList<Enroll> getAll() {
		// TODO Auto-generated method stub
		ArrayList<Enroll> enrollList=new ArrayList<Enroll>();
		String select="select * from enroll";
		try {
			PreparedStatement ps=con.prepareStatement(select);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				int enrollID=rs.getInt("enrollID");
				int employeeID=rs.getInt("employeeID");
				int projectID=rs.getInt("projectID");
				Date enrollDate=rs.getDate("enrollDate");
				Enroll en=new Enroll(enrollID, employeeID, projectID, enrollDate);
				enrollList.add(en);
			}
			rs.close();
			ps.close();
			return enrollList;
		}catch(SQLException e) {
			System.err.println(e.getMessage());			
			return null;
		}
	}

}
