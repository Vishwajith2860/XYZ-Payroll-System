package User;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Image;
import java.util.ArrayList;

import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import Data.*;
import Business.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Date;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.Color;

public class EnrollUI extends JFrame {

	private JPanel contentPane;
	private JTextField txtEnrollID;
	private JTextField txtEnrollDate;
    private EnrollDB eDB;
    private EmployeeDB employeeDB;
    private ProjectDB pDB;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EnrollUI frame = new EnrollUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public EnrollUI() {
		setResizable(false);
		setTitle("Enroll ");
		setBounds(100, 100, 611, 690);
		setLocationRelativeTo(this);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(127, 255, 212));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		eDB=new EnrollDB();
		pDB=new ProjectDB();
		employeeDB=new EmployeeDB();
		
		JLabel lblEnrollID = new JLabel("Enroll ID");
		lblEnrollID.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblEnrollID.setBounds(55, 35, 83, 13);
		contentPane.add(lblEnrollID);
		
		JLabel lblEmployeeId = new JLabel("Employee ID");
		lblEmployeeId.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblEmployeeId.setBounds(55, 80, 83, 13);
		contentPane.add(lblEmployeeId);
		
		JLabel lblProjectId = new JLabel("Project ID");
		lblProjectId.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblProjectId.setBounds(55, 131, 83, 13);
		contentPane.add(lblProjectId);
		
		JLabel lblEnrollDate = new JLabel("Enroll Date");
		lblEnrollDate.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblEnrollDate.setBounds(55, 185, 83, 13);
		contentPane.add(lblEnrollDate);
		
		txtEnrollID = new JTextField();
		txtEnrollID.setBounds(212, 32, 213, 19);
		contentPane.add(txtEnrollID);
		txtEnrollID.setColumns(10);
		
		txtEnrollDate = new JTextField();
		txtEnrollDate.setColumns(10);
		txtEnrollDate.setBounds(212, 182, 213, 19);
		contentPane.add(txtEnrollDate);
		
		JComboBox cmbEmployeeID = new JComboBox();
		cmbEmployeeID.setBounds(212, 77, 213, 21);
		contentPane.add(cmbEmployeeID);
		
		ArrayList<Employee> empList=employeeDB.getAll();
		for(Employee e : empList) {
			cmbEmployeeID.addItem(e.getEmpID());
		}
		
		JComboBox cmbProjectID = new JComboBox();
		cmbProjectID.setBounds(212, 128, 213, 21);
		contentPane.add(cmbProjectID);
		
		ArrayList<Project> pList=pDB.getAll();
		for(Project p : pList) {
			cmbProjectID.addItem(p.getProjectID());
		}
		
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 393, 574, 245);
		contentPane.add(scrollPane);
		
		
		JTable tblEnroll =new JTable();
		tblEnroll.setBounds(67, 393, 487, 241);
		scrollPane.setViewportView(tblEnroll);
		
		DefaultTableModel tblModel=new DefaultTableModel();
		tblModel.addColumn("Enroll ID");
		tblModel.addColumn("Employee ID");
		tblModel.addColumn("Project ID");
		tblModel.addColumn("Enroll Date");
		tblEnroll.setModel(tblModel);;
		
		JButton btnAdd = new JButton("Add");
		btnAdd.addActionListener(new ActionListener() {			
			public void actionPerformed(ActionEvent e) {
				
				if(checkValidation()) {
					int enrollID=Integer.valueOf(txtEnrollID.getText());
					int employeeID=Integer.valueOf(cmbEmployeeID.getSelectedItem().toString());
					int projectID=Integer.valueOf(cmbProjectID.getSelectedItem().toString());
					Date enrollDate=Date.valueOf(txtEnrollDate.getText());
					Enroll em=new Enroll(enrollID, employeeID, projectID, enrollDate);
					boolean added=eDB.add(em);
					if(added) {
						JOptionPane.showMessageDialog(contentPane, "The employee is enrolled to a project");
					}else {
						JOptionPane.showMessageDialog(contentPane, "The employee is not enrolled to a project");
					}
				}
				
			}
		});
		btnAdd.setBounds(55, 259, 97, 21);
		contentPane.add(btnAdd);
		
		JButton btnUpdate = new JButton("Update");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(checkValidation()) {
					int enrollID=Integer.valueOf(txtEnrollID.getText());
					int employeeID=Integer.valueOf(cmbEmployeeID.getSelectedItem().toString());
					int projectID=Integer.valueOf(cmbProjectID.getSelectedItem().toString());
					Date enrollDate=Date.valueOf(txtEnrollDate.getText());
					Enroll em=new Enroll(enrollID, employeeID, projectID, enrollDate);
					boolean updated=eDB.update(em);
					if(updated) {
						JOptionPane.showMessageDialog(contentPane, "The enroll is updated");
					}else {
						JOptionPane.showMessageDialog(contentPane, "The enroll is not updated");
					}
				}				
				
			}
		});
		btnUpdate.setBounds(194, 259, 97, 21);
		contentPane.add(btnUpdate);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int enrollID=Integer.valueOf(JOptionPane.showInputDialog(contentPane, "Enter a Enroll ID"));
				boolean deleted=eDB.delete(enrollID);
				if(deleted) {
					JOptionPane.showMessageDialog(contentPane, "The enroll is deleted");
				}else {
					JOptionPane.showMessageDialog(contentPane, "The enroll is not deleted");
				}
			}
		});
		btnDelete.setBounds(319, 259, 103, 21);
		contentPane.add(btnDelete);
		
		JButton btnFind = new JButton("Find");
		btnFind.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int enrollID=Integer.valueOf(JOptionPane.showInputDialog(contentPane, "Enter a Enroll ID"));
				Enroll em=eDB.get(enrollID);
				if(em!=null) {
					txtEnrollID.setText(String.valueOf(em.getEnrollID()));
					cmbEmployeeID.setSelectedItem(em.getEmployeeID());
					cmbProjectID.setSelectedItem(em.getProjectID());
					txtEnrollDate.setText(String.valueOf(em.getEnrollDate()));
				}
			}
		});
		btnFind.setBounds(451, 259, 103, 21);
		contentPane.add(btnFind);
		
		JButton btnGetAll = new JButton("Get All");
		btnGetAll.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ArrayList<Enroll> enList=eDB.getAll();
				tblModel.setRowCount(0);
				for(Enroll en:enList) {
					int enrollID=en.getEnrollID();
					int employeeID=en.getEmployeeID();
					int projectID=en.getProjectID();
					Date enrollDate=en.getEnrollDate();
					tblModel.addRow(new Object[] {enrollID, employeeID, projectID,enrollDate});
				}
				
			}
		});
		btnGetAll.setBounds(123, 318, 97, 21);
		contentPane.add(btnGetAll);
		
		JButton btnReset = new JButton("Reset");
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtEnrollID.setText(" ");
				txtEnrollDate.setText(" ");
			}
		});
		btnReset.setBounds(257, 318, 97, 21);
		contentPane.add(btnReset);
		
		JButton btnClose = new JButton("Close");
		btnClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			};
		});
		btnClose.setBounds(389, 318, 99, 21);
		contentPane.add(btnClose);
		
		JLabel label5 = new JLabel("");
		Image img = new ImageIcon(this.getClass().getResource("/enroll.png")).getImage();
		label5.setIcon(new ImageIcon (img));
		label5.setBounds(442, 32, 153, 141);
		contentPane.add(label5);
		
		
	}
	
	private boolean checkValidation() {
		try {
			int enrollID=Integer.valueOf(txtEnrollID.getText());
		}catch(Exception e) {
			JOptionPane.showMessageDialog(contentPane, "The enroll ID must be numeric");
			return false;
		}
		
		try {
			Date enrollDate=Date.valueOf(txtEnrollDate.getText());
		}catch(Exception e) {
			JOptionPane.showMessageDialog(contentPane, "The enroll date must be in YYYY-MM-DD format");
		  return false;
		}
		
		return true;
	}
}
