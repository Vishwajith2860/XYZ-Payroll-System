package User;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import Business.Login;
import Data.logDB;
import javax.swing.JOptionPane;
import java.awt.Color;
import java.awt.SystemColor;

public class NewLoginUI extends JFrame {

	private JPanel contentPane;
	private JTextField txtUserID;
	private JPasswordField txtPassword;
	private JPasswordField passwordField;
	private JPasswordField txtConfirmPassword;
	private logDB lDB;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					NewLoginUI frame = new NewLoginUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public NewLoginUI() {
		setResizable(false);
		setTitle("New Login");
		setBounds(100, 100, 552, 390);
		setLocationRelativeTo(this);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(135, 206, 250));
		contentPane.setForeground(new Color(102, 205, 170));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		lDB=new logDB();
		
		JLabel lblUserID = new JLabel("User ID");
		lblUserID.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblUserID.setBounds(67, 64, 107, 30);
		contentPane.add(lblUserID);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblPassword.setBounds(67, 117, 107, 30);
		contentPane.add(lblPassword);
		
		JLabel lblConfirmpassword = new JLabel("ConfirmPassword");
		lblConfirmpassword.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblConfirmpassword.setBounds(67, 179, 107, 30);
		contentPane.add(lblConfirmpassword);
		
		txtUserID = new JTextField();
		txtUserID.setBounds(219, 70, 196, 19);
		contentPane.add(txtUserID);
		txtUserID.setColumns(10);
		
		txtPassword = new JPasswordField();
		txtPassword.setBounds(219, 123, 196, 19);
		contentPane.add(txtPassword);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(408, 200, -131, 19);
		contentPane.add(passwordField);
		
		txtConfirmPassword = new JPasswordField();
		txtConfirmPassword.setBounds(219, 185, 196, 19);
		contentPane.add(txtConfirmPassword);
		
		JButton btnOK = new JButton("OK");
		btnOK.setBackground(new Color(127, 255, 212));
		btnOK.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(checkValidation()) {
					String userID=txtUserID.getText();
					String password=txtPassword.getText();
					String confirmPassword=txtConfirmPassword.getText();
					
					if(password.equals(confirmPassword)) {
						Login log=new Login(userID, confirmPassword);
						boolean added=lDB.add(log);
						if(added) {
							JOptionPane.showMessageDialog(contentPane, "New Login is added");
						}else {
							JOptionPane.showMessageDialog(contentPane, "New Login is not added");
						}
					}
				}
				
			}
		});
		btnOK.setBounds(67, 268, 150, 21);
		contentPane.add(btnOK);
		
		JButton btnCancel = new JButton("CANCEL");
		btnCancel.setBackground(new Color(127, 255, 212));
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		btnCancel.setBounds(265, 268, 150, 21);
		contentPane.add(btnCancel);
		
		JLabel label2 = new JLabel("");
		Image img = new ImageIcon(this.getClass().getResource("/login.png")).getImage();
		label2.setIcon(new ImageIcon (img));
		label2.setBounds(425, 11, 105, 100);
		contentPane.add(label2);
	}
	
	private boolean checkValidation() {
		if(txtUserID.getText().equals("")) {
			JOptionPane.showMessageDialog(contentPane, "User ID cannot be blank");
			return false;
		}
		
		if(txtPassword.getText().equals("")) {
			JOptionPane.showMessageDialog(contentPane, "Password cannot be blank");
			return false;
		}
		
		if(txtConfirmPassword.getText().equals("")) {
			JOptionPane.showMessageDialog(contentPane, "Confirm password cannot be blank");
			return false;
		}
		
		if(!txtPassword.getText().equals(txtConfirmPassword.getText())) {
			JOptionPane.showMessageDialog(contentPane, "Password must be matched with confirm password");
			return false;
		}
		
		return true;
		
	}
}
