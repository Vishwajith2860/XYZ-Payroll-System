package User;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;

import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import Business.Project;
import Data.ProjectDB;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.Color;

public class ProjectUI extends JFrame {

	private JPanel contentPane;
	private JTextField txtProjectID;
	private JTextField txtTitle;
	private JTextField txtDuration;
	private ProjectDB pDB;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ProjectUI frame = new ProjectUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ProjectUI() {
		setResizable(false);
		setTitle("Project");
		setBounds(100, 100, 603, 581);
		setLocationRelativeTo(this);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(245, 245, 220));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		pDB=new ProjectDB();
		
		JLabel lblProjectID = new JLabel("Project ID");
		lblProjectID.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblProjectID.setBounds(74, 56, 90, 13);
		contentPane.add(lblProjectID);
		
		JLabel lblTitle = new JLabel("Title");
		lblTitle.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblTitle.setBounds(74, 106, 90, 13);
		contentPane.add(lblTitle);
		
		JLabel lblDuration = new JLabel("Duration");
		lblDuration.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblDuration.setBounds(74, 155, 90, 13);
		contentPane.add(lblDuration);
		
		txtProjectID = new JTextField();
		txtProjectID.setBounds(206, 53, 227, 19);
		contentPane.add(txtProjectID);
		txtProjectID.setColumns(10);
		
		txtTitle = new JTextField();
		txtTitle.setColumns(10);
		txtTitle.setBounds(206, 103, 227, 19);
		contentPane.add(txtTitle);
		
		txtDuration = new JTextField();
		txtDuration.setColumns(10);
		txtDuration.setBounds(206, 152, 227, 19);
		contentPane.add(txtDuration);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(22, 359, 550, 170);
		contentPane.add(scrollPane);
		
		JTable tblProject=new JTable();
		tblProject.setBounds(62, 366, 461, 164);
		scrollPane.setViewportView(tblProject);
		
		DefaultTableModel tblModel=new DefaultTableModel();
		tblModel.addColumn("Project ID");
		tblModel.addColumn("Title");
		tblModel.addColumn("Duration");
		tblProject.setModel(tblModel);
		
		
		JButton btnAdd = new JButton("Add");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(checkValidation()) {
					int projectID=Integer.valueOf(txtProjectID.getText());
					String title=txtTitle.getText();
					int duration=Integer.valueOf(txtDuration.getText());
					
					Project p=new Project(projectID, title, duration);
					boolean added=pDB.add(p);
					if(added) {
						JOptionPane.showMessageDialog(contentPane, "New Project is added");
					}else {
						JOptionPane.showMessageDialog(contentPane, "New Project is not added");
					}
				}
				
				
			}
		});
		btnAdd.setBounds(37, 224, 110, 21);
		contentPane.add(btnAdd);
		
		JButton btnUpdate = new JButton("Update");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(checkValidation()) {
					int projectID=Integer.valueOf(txtProjectID.getText());
					String title=txtTitle.getText();
					int duration=Integer.valueOf(txtDuration.getText());
					
					Project p=new Project(projectID, title, duration);
					boolean updated=pDB.update(p);
					if(updated) {
						JOptionPane.showMessageDialog(contentPane, "The Project is updated");
					}else {
						JOptionPane.showMessageDialog(contentPane, "The Project is not updated");
					}
				}
				
			}
		});
		btnUpdate.setBounds(173, 224, 110, 21);
		contentPane.add(btnUpdate);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int projectID=Integer.valueOf(JOptionPane.showInputDialog(contentPane, "Enter the Project ID"));
			    boolean deleted=pDB.delete(projectID);
			    if(deleted) {
					JOptionPane.showMessageDialog(contentPane, "The Project is deleted");
				}else {
					JOptionPane.showMessageDialog(contentPane, "The Project is not deleted");
				}
			}
		});
		btnDelete.setBounds(306, 224, 110, 21);
		contentPane.add(btnDelete);
		
		JButton btnFind = new JButton("Find");
		btnFind.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int projectID=Integer.valueOf(JOptionPane.showInputDialog(contentPane, "Enter the Project ID"));
			    Project p=pDB.get(projectID);
			    if(p!=null) {
			    	txtProjectID.setText(String.valueOf(p.getProjectID()));
			    	txtTitle.setText(p.getTitle());
			    	txtDuration.setText(String.valueOf(p.getDuration()));
			    }
			    }
		});
		btnFind.setBounds(437, 224, 110, 21);
		contentPane.add(btnFind);
		
		JButton btnGetAll = new JButton("Get All");
		btnGetAll.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tblModel.setRowCount(0);
				ArrayList<Project> pList=pDB.getAll();
				for(Project p:pList) {
					int projectID=p.getProjectID();
					String title=p.getTitle();
					int duration=p.getDuration();
					tblModel.addRow(new Object[] {projectID, title, duration});
				}
				
			}
		});
		btnGetAll.setBounds(104, 291, 110, 21);
		contentPane.add(btnGetAll);
		
		JButton btnReset = new JButton("Reset");
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtProjectID.setText("");
				txtTitle.setText("");
				txtDuration.setText("");
			}
		});
		btnReset.setBounds(242, 291, 108, 21);
		contentPane.add(btnReset);
		
		JButton btnClose = new JButton("Close");
		btnClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		btnClose.setBounds(377, 291, 108, 21);
		contentPane.add(btnClose);		
		
		JLabel label6 = new JLabel("");
		Image img = new ImageIcon(this.getClass().getResource("/project.png")).getImage();
		label6.setIcon(new ImageIcon (img));
		label6.setBounds(433, 11, 154, 157);
		contentPane.add(label6);
		
	}
	
	private boolean checkValidation() {
		try {
			int projectID=Integer.valueOf(txtProjectID.getText());
		}catch(Exception e) {
			JOptionPane.showMessageDialog(contentPane, "The Project ID must be numeric");
			return false;
		}
		
		if(txtTitle.getText().equals("")) {
			JOptionPane.showMessageDialog(contentPane, "The title cannot be blank");
			return false;
		}
		
		try {
			int duration=Integer.valueOf(txtDuration.getText());
		}catch(Exception e) {
			JOptionPane.showMessageDialog(contentPane, "The duration must be numeric");
			return false;
		}
		
		return true;
	}
}
