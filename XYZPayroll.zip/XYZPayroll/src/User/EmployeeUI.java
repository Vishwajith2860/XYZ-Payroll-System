package User;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import Business.Employee;
import Data.EmployeeDB;
import javax.swing.JOptionPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.awt.Color;

public class EmployeeUI extends JFrame {

	private JPanel contentPane;
	private JTextField txtEpf;
	private JTextField txtFirstName;
	private JTextField txtLastName;
	private JTextField txtAddress;
	private JTextField txtBank;
	private JTextField txtAccountNumber;
	private EmployeeDB empDB;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EmployeeUI frame = new EmployeeUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public EmployeeUI() {
		setResizable(false);
		setTitle("Employee");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 640, 794);
		setLocationRelativeTo(this);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 204, 204));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		empDB=new EmployeeDB();
		
		JLabel lblEpf = new JLabel("EPF Number");
		lblEpf.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblEpf.setBounds(63, 55, 112, 13);
		contentPane.add(lblEpf);
		
		JLabel lblFirstName = new JLabel("First Name");
		lblFirstName.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblFirstName.setBounds(63, 98, 112, 13);
		contentPane.add(lblFirstName);
		
		JLabel lblLastName = new JLabel("Last Name");
		lblLastName.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblLastName.setBounds(63, 141, 112, 13);
		contentPane.add(lblLastName);
		
		JLabel lblAddress = new JLabel("Address");
		lblAddress.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblAddress.setBounds(63, 181, 112, 13);
		contentPane.add(lblAddress);
		
		JLabel lblBank = new JLabel("Bank");
		lblBank.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblBank.setBounds(63, 223, 112, 13);
		contentPane.add(lblBank);
		
		JLabel lblAccountNumber = new JLabel("Account Number");
		lblAccountNumber.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblAccountNumber.setBounds(63, 269, 112, 13);
		contentPane.add(lblAccountNumber);
		
		JLabel lblSalaryType = new JLabel("Salary Type");
		lblSalaryType.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblSalaryType.setBounds(63, 319, 112, 13);
		contentPane.add(lblSalaryType);
		
		txtEpf = new JTextField();
		txtEpf.setBounds(235, 53, 219, 19);
		contentPane.add(txtEpf);
		txtEpf.setColumns(10);
		
		txtFirstName = new JTextField();
		txtFirstName.setColumns(10);
		txtFirstName.setBounds(235, 96, 219, 19);
		contentPane.add(txtFirstName);
		
		txtLastName = new JTextField();
		txtLastName.setColumns(10);
		txtLastName.setBounds(235, 139, 219, 19);
		contentPane.add(txtLastName);
		
		txtAddress = new JTextField();
		txtAddress.setColumns(10);
		txtAddress.setBounds(235, 179, 219, 19);
		contentPane.add(txtAddress);
		
		txtBank = new JTextField();
		txtBank.setColumns(10);
		txtBank.setBounds(235, 220, 219, 19);
		contentPane.add(txtBank);
		
		txtAccountNumber= new JTextField();
		txtAccountNumber.setColumns(10);
		txtAccountNumber.setBounds(235, 266, 219, 19);
		contentPane.add(txtAccountNumber);
		
		JComboBox cmbSalaryType = new JComboBox();
		cmbSalaryType.setModel(new DefaultComboBoxModel(new String[] {"Monthly", "Hourly"}));
		cmbSalaryType.setBounds(237, 316, 97, 21);
		contentPane.add(cmbSalaryType);
		
		JTable tblEmployee =new JTable();
		DefaultTableModel tblModel=new DefaultTableModel();
		tblModel.addColumn("EPF");
		tblModel.addColumn("First Name");
		tblModel.addColumn("Last Name");
		tblModel.addColumn("Address");
		tblModel.addColumn("Bank");
		tblModel.addColumn("Account Number");
		tblModel.addColumn("Salary Type");
		tblEmployee.setModel(tblModel);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 508, 603, 234);
		scrollPane.setViewportView(tblEmployee);
		contentPane.add(scrollPane);
		
		JButton btnAdd = new JButton("Add");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(checkValidation()) {
					int epf=Integer.valueOf(txtEpf.getText());
					String firstName=txtFirstName.getText();
					String lastName=txtLastName.getText();
					String address=txtAddress.getText();
					String bank=txtBank.getText();
					String accountno=txtAccountNumber.getText();
					String salarytype=cmbSalaryType.getSelectedItem().toString();
					
					Employee emp=new Employee(epf, firstName, lastName, address, bank, accountno, salarytype);
					boolean added=empDB.add(emp);
					if(added) {
						JOptionPane.showMessageDialog(contentPane, "New Employee is added");
					}else {
						JOptionPane.showMessageDialog(contentPane, "New Employee is not added");
					}
				}
				
				
			}
		});
		btnAdd.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnAdd.setBounds(45, 398, 135, 21);
		contentPane.add(btnAdd);
		
		JButton btnUpdate = new JButton("Update");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(checkValidation()) {
					int epfNumber=Integer.valueOf(txtEpf.getText());
					String firstName=txtFirstName.getText();
					String lastName=txtLastName.getText();
					String address=txtAddress.getText();
					String bank=txtBank.getText();
					String accountno=txtAccountNumber.getText();
					String salarytype=cmbSalaryType.getSelectedItem().toString();
					
					Employee emp=new Employee(epfNumber, firstName, lastName, address, bank, accountno, salarytype);
					boolean updated=empDB.update(emp);
					if(updated) {
						JOptionPane.showMessageDialog(contentPane, "Employee record is updated");
					}else {
						JOptionPane.showMessageDialog(contentPane, "Employee record  is not updated");
					}
				}
								
			}
		});
		btnUpdate.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnUpdate.setBounds(252, 398, 135, 21);
		contentPane.add(btnUpdate);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int epfNumber=Integer.valueOf(JOptionPane.showInputDialog(contentPane, "Enter EPF Numbar"));
				boolean deleted=empDB.delete(epfNumber);
				if(deleted) {
					JOptionPane.showMessageDialog(contentPane, "Employee record is deleted");
				}else {
					JOptionPane.showMessageDialog(contentPane, "Employee record  is not deleted");
				}		
				
			}
		});
		btnDelete.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnDelete.setBounds(456, 398, 135, 21);
		contentPane.add(btnDelete);
		
		JButton btnFind = new JButton("Find");
		btnFind.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int epf=Integer.valueOf(JOptionPane.showInputDialog(contentPane, "Enter EPF Numbar"));
				Employee emp=empDB.get(epf);
				if(emp!=null) {
					txtEpf.setText(String.valueOf(emp.getEpfNumber()));
					txtFirstName.setText(emp.getFirstName());
					txtLastName.setText(emp.getLastName());
					txtAddress.setText(emp.getAddress());
					txtBank.setText(emp.getBank());
					txtAccountNumber.setText(emp.getAccountNumber());
					cmbSalaryType.setSelectedItem(emp.getSalaryType());
					
				}
				
			}
		});
		btnFind.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnFind.setBounds(45, 449, 130, 21);
		contentPane.add(btnFind);
		
		JButton btnGetAll = new JButton("Get All");
		btnGetAll.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tblModel.setRowCount(0);
				ArrayList<Employee> empList=empDB.getAll();
				for(Employee emp:empList) {
					int epfNumber=emp.getEpfNumber();
					String firstName=emp.getFirstName();
					String lastName=emp.getLastName();
					String address=emp.getAddress();
					String bank=emp.getBank();
					String accountno=emp.getAccountNumber();
					String salarytype=emp.getSalaryType();
					tblModel.addRow(new Object[] {epfNumber,firstName,lastName,address,bank,accountno,salarytype});
				}
			}
		});
		btnGetAll.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnGetAll.setBounds(252, 449, 132, 21);
		contentPane.add(btnGetAll);
		
		JButton btnReset = new JButton("Reset");
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtEpf.setText("");
				txtFirstName.setText("");
				txtLastName.setText("");
				txtAddress.setText("");
				txtBank.setText("");
				txtAccountNumber.setText("");
				
			}
		});
		btnReset.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnReset.setBounds(456, 449, 135, 21);
		contentPane.add(btnReset);
		
		JButton btnClose = new JButton("Close");
		btnClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnClose.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnClose.setBounds(506, 28, 85, 21);
		contentPane.add(btnClose);
		
		JLabel label3 = new JLabel("");
		Image img = new ImageIcon(this.getClass().getResource("/employee.png")).getImage();
		label3.setIcon(new ImageIcon (img));
		label3.setBounds(478, 85, 146, 134);
		contentPane.add(label3);
		
		
	}
	
	private boolean checkValidation() {
		 try {
			 int epfNumber=Integer.valueOf(txtEpf.getText());
		 }catch(NumberFormatException e) {
			 JOptionPane.showMessageDialog(contentPane, "EPF must be a numeric value");
			 return false;
		 }
		 
		 if(txtFirstName.getText().equals("")) {
			 JOptionPane.showMessageDialog(contentPane, "First Name cannot be blank");
			 return false;
		 }
		 
		 if(txtLastName.getText().equals("")) {
			 JOptionPane.showMessageDialog(contentPane, "Last Name cannot be blank");
			 return false;
		 }
		 
		 if(txtAddress.getText().equals("")) {
			 JOptionPane.showMessageDialog(contentPane, "Address cannot be blank");
			 return false;
		 }
		 
		 if(txtBank.getText().equals("")) {
			 JOptionPane.showMessageDialog(contentPane, "Bank Name cannot be blank");
			 return false;
		 }
		 
		 if(txtAccountNumber.getText().equals("")) {
			 JOptionPane.showMessageDialog(contentPane, "Account Number cannot be blank");
			 return false;
		 }
		 
		 return true;
	 }
}
