package User;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import Data.logDB;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JOptionPane;
import java.awt.Color;

public class DeleteLoginUI extends JFrame {

	private JPanel contentPane;
    private logDB lDB;
    private JTextField txtUserID;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DeleteLoginUI frame = new DeleteLoginUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public DeleteLoginUI() {
		setResizable(false);
		setTitle("Delete Login");
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		setBounds(100, 100, 466, 231);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 102, 102));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblUserID = new JLabel("  User ID");
		lblUserID.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblUserID.setBounds(51, 47, 101, 25);
		contentPane.add(lblUserID);
		
		txtUserID = new JTextField();
		txtUserID.setBounds(162, 50, 185, 19);
		contentPane.add(txtUserID);
		txtUserID.setColumns(10);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(checkValidation()) {
					String userID=txtUserID.getText();
					boolean deleted=lDB.delete(userID);
					
					if(deleted) {
						JOptionPane.showMessageDialog(contentPane, "Login is deleted");
					}else {
						JOptionPane.showMessageDialog(contentPane, "Login is deleted");
					}
				}
		
			}
		});
		btnDelete.setBounds(51, 122, 124, 21);
		contentPane.add(btnDelete);
		
		JButton btnCancel = new JButton("Cancel");
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		btnCancel.setBounds(223, 122, 124, 21);
		contentPane.add(btnCancel);
		
		JLabel label8 = new JLabel("");
		Image img = new ImageIcon(this.getClass().getResource("/deletelogin.png")).getImage();
		label8.setIcon(new ImageIcon (img));
		label8.setBounds(347, 11, 92, 93);
		contentPane.add(label8);
		
		
		setLocationRelativeTo(this);
		
		lDB=new logDB();
		
	}

	private boolean checkValidation() {
		if(txtUserID.getText().equals("")) {
			JOptionPane.showMessageDialog(contentPane, "User ID cannot be blank");
			return false;
		}	
				
		return true;		
	}
	
	
}
