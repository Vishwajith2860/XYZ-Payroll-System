package User;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.*;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JOptionPane;
import Business.Employee;
import Business.SalarySlip;
import Data.EmployeeDB;
import Data.SalarySlipDB;
import java.util.*;
import java.awt.Color;

public class SalarySlipUI extends JFrame {

	private JPanel contentPane;
	private JTextField txtSlipID;
	private JTextField txtHourlyRate;
	private JTextField txtHoursWKD;
	private JTextField txtEPF;
	private JTextField txtTax;
	private JTextField txtAllowance;
	private JTextField txtGrossSalary;
	private JTextField txtNetSalary;
	private EmployeeDB empDB;
	private SalarySlipDB sDB;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SalarySlipUI frame = new SalarySlipUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SalarySlipUI() {
		setBackground(new Color(153, 204, 255));
		setTitle("Salary Slip");
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 639, 800);
		setLocationRelativeTo(this);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 153, 153));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		empDB=new EmployeeDB();
		sDB=new SalarySlipDB();
		
		JLabel lblSalarySlipID = new JLabel("Salary Slip ID");
		lblSalarySlipID.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblSalarySlipID.setBounds(42, 29, 109, 13);
		contentPane.add(lblSalarySlipID);
		
		JLabel lblEpfNumber = new JLabel("EPF Number");
		lblEpfNumber.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblEpfNumber.setBounds(42, 73, 109, 13);
		contentPane.add(lblEpfNumber);
		
		JLabel lblMonth = new JLabel("Month");
		lblMonth.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblMonth.setBounds(42, 117, 109, 13);
		contentPane.add(lblMonth);
		
		JLabel lblYear = new JLabel("Year");
		lblYear.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblYear.setBounds(42, 159, 109, 13);
		contentPane.add(lblYear);
		
		JLabel lblHourlyRate = new JLabel("Hourly Rate");
		lblHourlyRate.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblHourlyRate.setBounds(42, 252, 109, 13);
		contentPane.add(lblHourlyRate);
		
		JLabel lblHoursWorked = new JLabel("Hours Worked");
		lblHoursWorked.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblHoursWorked.setBounds(42, 296, 109, 13);
		contentPane.add(lblHoursWorked);
		
		JLabel lblEpf = new JLabel("EPF");
		lblEpf.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblEpf.setBounds(42, 390, 109, 13);
		contentPane.add(lblEpf);
		
		JLabel lblTax = new JLabel("TAX");
		lblTax.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblTax.setBounds(42, 432, 109, 13);
		contentPane.add(lblTax);
		
		JLabel lblAllowance = new JLabel("Allowance");
		lblAllowance.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblAllowance.setBounds(42, 477, 109, 13);
		contentPane.add(lblAllowance);
		
		JLabel lblGrossSalary = new JLabel("Gross Salary");
		lblGrossSalary.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblGrossSalary.setBounds(42, 342, 109, 13);
		contentPane.add(lblGrossSalary);
		
		JLabel lblNetSalary = new JLabel("Net Salary");
		lblNetSalary.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNetSalary.setBounds(42, 520, 109, 13);
		contentPane.add(lblNetSalary);
		
		txtSlipID = new JTextField();
		txtSlipID.setBounds(196, 27, 153, 19);
		contentPane.add(txtSlipID);
		txtSlipID.setColumns(10);
		
		JComboBox cmbEPFNumber = new JComboBox();
		cmbEPFNumber.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		cmbEPFNumber.setBounds(196, 70, 153, 21);
		contentPane.add(cmbEPFNumber);
		
		ArrayList<Employee> empList=empDB.getAll();
		for(Employee emp:empList) {
			cmbEPFNumber.addItem(emp.getEpfNumber());
		}
		
		JComboBox cmbMonth = new JComboBox();
		cmbMonth.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"}));
		cmbMonth.setBounds(196, 114, 153, 21);
		contentPane.add(cmbMonth);
		
		JComboBox cmbYear = new JComboBox();
		cmbYear.setModel(new DefaultComboBoxModel(new String[] {"2021", "2022", "2023", "2024", "2025"}));
		cmbYear.setBounds(196, 156, 153, 21);
		contentPane.add(cmbYear);
		
		txtHourlyRate = new JTextField();
		txtHourlyRate.setColumns(10);
		txtHourlyRate.setBounds(196, 249, 153, 19);
		contentPane.add(txtHourlyRate);
		
		txtHoursWKD = new JTextField();
		txtHoursWKD.setColumns(10);
		txtHoursWKD.setBounds(196, 294, 153, 19);
		contentPane.add(txtHoursWKD);
		
		txtEPF = new JTextField();
		txtEPF.setColumns(10);
		txtEPF.setBounds(196, 388, 153, 19);
		contentPane.add(txtEPF);
		
		txtTax = new JTextField();
		txtTax.setColumns(10);
		txtTax.setBounds(196, 430, 153, 19);
		contentPane.add(txtTax);
		
		txtAllowance = new JTextField();
		txtAllowance.setColumns(10);
		txtAllowance.setBounds(196, 475, 153, 19);
		contentPane.add(txtAllowance);
		
		txtGrossSalary = new JTextField();
		txtGrossSalary.setColumns(10);
		txtGrossSalary.setBounds(196, 340, 153, 19);
		txtGrossSalary.setText("0");
		contentPane.add(txtGrossSalary);
		
		txtNetSalary = new JTextField();
		txtNetSalary.setColumns(10);
		txtNetSalary.setBounds(196, 518, 153, 19);
		txtNetSalary.setText("0");
		txtNetSalary.setEnabled(false);
		contentPane.add(txtNetSalary);
		
		
		
		JTable tblSalarySlip=new JTable();
		DefaultTableModel tblModel=new DefaultTableModel();
		tblModel.addColumn("Salary Slip ID");
		tblModel.addColumn("EPF Number");
		tblModel.addColumn("Month");
		tblModel.addColumn("Year");
		tblModel.addColumn("Hourly Rate");
		tblModel.addColumn("Hours Worked");
		tblModel.addColumn("EPF");
		tblModel.addColumn("Tax");
		tblModel.addColumn("Allowance");
		tblModel.addColumn("Gross Salary");
		tblModel.addColumn("Net Salary");
		tblSalarySlip.setModel(tblModel);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 571, 601, 178);
		scrollPane.setViewportView(tblSalarySlip);
		contentPane.add(scrollPane);
		
		JButton btnAdd = new JButton("Add");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int slipID=Integer.valueOf(txtSlipID.getText());
				int epfNumber=Integer.valueOf(cmbEPFNumber.getSelectedItem().toString());
				int month=Integer.valueOf(cmbMonth.getSelectedItem().toString());
				int year=Integer.valueOf(cmbYear.getSelectedItem().toString());
				double hourlyRate=Double.valueOf(txtHourlyRate.getText());
				int hoursWKD=Integer.valueOf(txtHoursWKD.getText());
				double epf=Double.valueOf(txtEPF.getText());
				double tax=Double.valueOf(txtTax.getText());
				double allowance=Double.valueOf(txtAllowance.getText());
				double gSalary=Double.valueOf(txtGrossSalary.getText());
				double netSalary=Double.valueOf(txtNetSalary.getText());
				
				SalarySlip ss=new SalarySlip();
				ss.setSlipID(slipID);
				ss.setEpfNumber(epfNumber);
				ss.setMonth(month);
				ss.setYear(year);
				ss.setHourlyRate(hourlyRate);
				ss.setHoursWorked(hoursWKD);
				ss.setEpf(epf);
				ss.setTax(tax);
				ss.setAllowance(allowance);
				ss.setgSalary(gSalary);
				ss.setNetSalary(netSalary);
				
				boolean added=sDB.add(ss);
				if(added) {
					JOptionPane.showMessageDialog(contentPane, "The salary slip is added");
				}else {
					JOptionPane.showMessageDialog(contentPane, "The salary slip is not added");
				}
				
			}
		});
		btnAdd.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnAdd.setBounds(430, 69, 153, 21);
		contentPane.add(btnAdd);
		
		JButton btnUpdate = new JButton("Update");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int slipID=Integer.valueOf(txtSlipID.getText());
				int epfNumber=Integer.valueOf(cmbEPFNumber.getSelectedItem().toString());
				int month=Integer.valueOf(cmbMonth.getSelectedItem().toString());
				int year=Integer.valueOf(cmbYear.getSelectedItem().toString());
				double hourlyRate=Double.valueOf(txtHourlyRate.getText());
				int hoursWKD=Integer.valueOf(txtHoursWKD.getText());
				double epf=Double.valueOf(txtEPF.getText());
				double tax=Double.valueOf(txtTax.getText());
				double allowance=Double.valueOf(txtAllowance.getText());
				double gSalary=Double.valueOf(txtGrossSalary.getText());
				double netSalary=Double.valueOf(txtNetSalary.getText());
				
				SalarySlip ss=new SalarySlip();
				ss.setSlipID(slipID);
				ss.setEpfNumber(epfNumber);
				ss.setMonth(month);
				ss.setYear(year);
				ss.setHourlyRate(hourlyRate);
				ss.setHoursWorked(hoursWKD);
				ss.setEpf(epf);
				ss.setTax(tax);
				ss.setAllowance(allowance);
				ss.setgSalary(gSalary);
				ss.setNetSalary(netSalary);
				
				boolean updated=sDB.update(ss);
				if(updated) {
					JOptionPane.showMessageDialog(contentPane, "The salary slip details are edited");
				}else {
					JOptionPane.showMessageDialog(contentPane, "The salary slip are not edited");
				}
				
			}
		});
		btnUpdate.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnUpdate.setBounds(430, 113, 153, 21);
		contentPane.add(btnUpdate);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int slipID=Integer.valueOf(JOptionPane.showInputDialog(contentPane, "Enter the slip ID"));
				
				boolean deleted=sDB.delete(slipID);
				if(deleted) {
					JOptionPane.showMessageDialog(contentPane, "The salary slip is deleted");
				}else {
					JOptionPane.showMessageDialog(contentPane, "The salary slip is not deleted");
				}
			}
		});
		btnDelete.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnDelete.setBounds(430, 155, 153, 21);
		contentPane.add(btnDelete);
		
		JButton btnFind = new JButton("Find");
		btnFind.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int slipID=Integer.valueOf(JOptionPane.showInputDialog(contentPane, "Enter the slip ID"));
				SalarySlip s=sDB.get(slipID);
				if(s!=null) {
					txtSlipID.setText(String.valueOf(s.getSlipID()));
					cmbEPFNumber.setSelectedItem(s.getEpfNumber());
					cmbMonth.setSelectedItem(String.valueOf(s.getMonth()));
					cmbYear.setSelectedItem(String.valueOf(s.getYear()));
					txtHourlyRate.setText(String.valueOf(s.getHourlyRate()));
					txtHoursWKD.setText(String.valueOf(s.getHoursWorked()));
					txtGrossSalary.setText(String.valueOf(s.getgSalary()));
					txtEPF.setText(String.valueOf(s.getEpf()));
					txtTax.setText(String.valueOf(s.getTax()));
					txtAllowance.setText(String.valueOf(s.getAllowance()));
					txtNetSalary.setText(String.valueOf(s.getNetSalary()));
					
				}
				
			}
		});
		btnFind.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnFind.setBounds(430, 203, 153, 21);
		contentPane.add(btnFind);
		
		JButton btnGetAll = new JButton("Get All");
		btnGetAll.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tblModel.setRowCount(0);
				ArrayList<SalarySlip> salarySlipList=sDB.getAll();
				for(SalarySlip s1: salarySlipList) {
					int slipID=s1.getSlipID();
					int epfNumber=s1.getEpfNumber();
					int month=s1.getMonth();
					int year=s1.getYear();
					double hRate=s1.getHourlyRate();
					int hrsWKD=s1.getHoursWorked();
					double epf=s1.getEpf();
					double tax=s1.getTax();
					double allowance=s1.getAllowance();
					double gSalary=s1.getgSalary();
					double nSalary=s1.getNetSalary();
					tblModel.addRow(new Object[] {slipID,epfNumber,month,year,hRate,hrsWKD,epf,tax,allowance,gSalary,nSalary});
				}
				
			}
		});
		btnGetAll.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnGetAll.setBounds(430, 248, 153, 21);
		contentPane.add(btnGetAll);
		
		JButton btnReset = new JButton("Reset");
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtSlipID.setText("");
				txtHourlyRate.setText("0");
				txtHoursWKD.setText("0");
				txtEPF.setText("0");
				txtTax.setText("0");
				txtAllowance.setText("0");
				txtGrossSalary.setText("0");
				txtNetSalary.setText("0");
			}
		});
		btnReset.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnReset.setBounds(430, 292, 153, 21);
		contentPane.add(btnReset);
		
		JButton btnClose = new JButton("Close");
		btnClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		btnClose.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnClose.setBounds(430, 338, 153, 21);
		contentPane.add(btnClose);
		
		JButton btnCalculateSalary = new JButton("Calculate Salary");
		btnCalculateSalary.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(checkValidation()) {
					int epfNumber=Integer.valueOf(cmbEPFNumber.getSelectedItem().toString());
					double gSalary=0;
					Employee emp=empDB.get(epfNumber);
					if(emp.getSalaryType().equals("Hourly")) {
						
						double hrRate=Double.valueOf(txtHourlyRate.getText());
						int hrsWKD=Integer.valueOf(txtHoursWKD.getText());
						gSalary=hrRate*hrsWKD;
						txtGrossSalary.setText(String.valueOf(gSalary));
					}else {
						txtHourlyRate.setText("0");
						txtHoursWKD.setText("0");
					}
					
					 gSalary=Double.valueOf(txtGrossSalary.getText());				
					double epf=Double.valueOf(txtEPF.getText());
					double tax=Double.valueOf(txtTax.getText());
					double allowance=Double.valueOf(txtAllowance.getText());
					
					double netSalary=gSalary+allowance-epf-tax;
					txtNetSalary.setText(String.valueOf(netSalary));
				}
							
			}
		});
		btnCalculateSalary.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnCalculateSalary.setBounds(430, 25, 153, 21);
		contentPane.add(btnCalculateSalary);
		
		JLabel lblDisplay = new JLabel("");
		lblDisplay.setBounds(215, 211, 45, 13);
		contentPane.add(lblDisplay);
		
		JButton btnSalaryType = new JButton("Check Salary Type");
		btnSalaryType.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int epfNumber=Integer.valueOf(cmbEPFNumber.getSelectedItem().toString());
				Employee emp=empDB.get(epfNumber);
				if(emp.getSalaryType().equals("Monthly")) {
					
					txtHourlyRate.setText("0");
					txtHoursWKD.setText("0");
					lblDisplay.setText("Monthly");
					txtHourlyRate.setEnabled(false);
					txtHoursWKD.setEnabled(false);
					txtGrossSalary.setEnabled(true);
				}else {
					txtHourlyRate.setText("");
					txtHoursWKD.setText("");
					lblDisplay.setText("Hourly");
					txtHourlyRate.setEnabled(true);
					txtHoursWKD.setEnabled(true);
					txtGrossSalary.setEnabled(false);
				}
				
			}
		});
		btnSalaryType.setBounds(42, 204, 121, 21);
		contentPane.add(btnSalaryType);	
		
		JLabel label7 = new JLabel("");
		Image img = new ImageIcon(this.getClass().getResource("/salaryslip.png")).getImage();
		label7.setIcon(new ImageIcon (img));
		label7.setBounds(423, 390, 160, 147);
		contentPane.add(label7);
	
	}
	
	private boolean checkValidation() {
		try {
			int slipID=Integer.valueOf(txtSlipID.getText());			
		}catch(Exception e) {
			JOptionPane.showMessageDialog(contentPane, "Slip ID must be numeric");
			return false;
		}
		
		try {
			double hourlyRate=Double.valueOf(txtHourlyRate.getText());		
		}catch(Exception e) {
			JOptionPane.showMessageDialog(contentPane, " Hourly rate must be numeric");
			return false;
		}
		
		try {
			int hoursWKD=Integer.valueOf(txtHoursWKD.getText());		
		}catch(Exception e) {
			JOptionPane.showMessageDialog(contentPane, " Hours worked  must be numeric");
			return false;
		}
		
		try {
			double gSalary=Double.valueOf(txtGrossSalary.getText());		
		}catch(Exception e) {
			JOptionPane.showMessageDialog(contentPane, " Gross salary  must be numeric");
			return false;
		}
		
		try {
			double epf=Double.valueOf(txtEPF.getText());	
		}catch(Exception e) {
			JOptionPane.showMessageDialog(contentPane, " EPF  must be numeric");
			return false;
		}
		
		try {
			double tax=Double.valueOf(txtTax.getText());	
		}catch(Exception e) {
			JOptionPane.showMessageDialog(contentPane, " Tax  must be numeric");
			return false;
		}
		
		try {
			double allowance=Double.valueOf(txtAllowance.getText());
		}catch(Exception e) {
			JOptionPane.showMessageDialog(contentPane, " Alowance  must be numeric");
			return false;
		}
		
		
		return true;
		
	}
}