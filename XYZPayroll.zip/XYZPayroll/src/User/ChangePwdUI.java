package User;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Business.Login;
import Data.logDB;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JOptionPane;
import java.awt.Color;

public class ChangePwdUI extends JFrame {

	private JPanel contentPane;
    private logDB lDB;
    private JTextField txtUserID;
    private JPasswordField txtNewPWD;
    private JPasswordField txtConNewPWD;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ChangePwdUI frame = new ChangePwdUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ChangePwdUI() {
		setResizable(false);
		setTitle("Change Password");
		setBounds(100, 100, 538, 357);
		setLocationRelativeTo(this);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 153, 204));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblUserID = new JLabel("User ID");
		lblUserID.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblUserID.setBounds(58, 56, 45, 13);
		contentPane.add(lblUserID);
		
		JLabel lblNewPassword = new JLabel("New Password");
		lblNewPassword.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewPassword.setBounds(58, 105, 99, 13);
		contentPane.add(lblNewPassword);
		
		JLabel lblConfirmNewPassword = new JLabel("Confirm New Password");
		lblConfirmNewPassword.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblConfirmNewPassword.setBounds(58, 154, 131, 13);
		contentPane.add(lblConfirmNewPassword);
		
		txtUserID = new JTextField();
		txtUserID.setBounds(216, 53, 173, 19);
		contentPane.add(txtUserID);
		txtUserID.setColumns(10);
		
		txtNewPWD = new JPasswordField();
		txtNewPWD.setBounds(216, 102, 173, 19);
		contentPane.add(txtNewPWD);
		
		txtConNewPWD = new JPasswordField();
		txtConNewPWD.setBounds(216, 151, 173, 19);
		contentPane.add(txtConNewPWD);
		
		JButton btnUpdate = new JButton("Update");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(checkValidation()) {
					String userID=txtUserID.getText();
					String newPassword=txtNewPWD.getText();
					String conNewPassword=txtConNewPWD.getText();
					
					if(newPassword.equals(conNewPassword)) {
						Login l=new Login(userID, newPassword);
						boolean updated=lDB.update(l);
						if(updated) {
							JOptionPane.showMessageDialog(contentPane, "Password is changed");
						}else {
							JOptionPane.showMessageDialog(contentPane, "Password is not changed");
						}
					}
				}
				
			}
		});
		btnUpdate.setBounds(58, 235, 131, 21);
		contentPane.add(btnUpdate);
		
		JButton btnCancel = new JButton("Cancel");
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		btnCancel.setBounds(269, 235, 131, 21);
		contentPane.add(btnCancel);
		
		JLabel label9 = new JLabel("");
		Image img = new ImageIcon(this.getClass().getResource("/chngpswrd.png")).getImage();
		label9.setIcon(new ImageIcon (img));
		label9.setBounds(394, 28, 128, 120);
		contentPane.add(label9);
		
		lDB=new logDB();
	}
	
	private boolean checkValidation() {
		if(txtUserID.getText().equals("")) {
			JOptionPane.showMessageDialog(contentPane, "User ID cannot be blank");
			return false;
		}
		
		if(txtNewPWD.getText().equals("")) {
			JOptionPane.showMessageDialog(contentPane, "Password cannot be blank");
			return false;
		}
		
		if(txtConNewPWD.getText().equals("")) {
			JOptionPane.showMessageDialog(contentPane, "Confirm password cannot be blank");
			return false;
		}
		
		if(!txtNewPWD.getText().equals(txtConNewPWD.getText())) {
			JOptionPane.showMessageDialog(contentPane, "Password must be matched with confirm password");
			return false;
		}
		
		return true;
		
	}

}
