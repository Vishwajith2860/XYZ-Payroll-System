package User;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JOptionPane;
import Business.Login;
import Data.logDB;
import java.awt.Color;
public class LoginUI extends JFrame {

	private JPanel contentPane;
	private JTextField txtUserID;
	private JPasswordField txtPassword;
	private logDB lDB;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginUI frame = new LoginUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LoginUI() {
		setResizable(false);
		setTitle("Login");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		setLocationRelativeTo(this);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 204, 153));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblUserID = new JLabel("User ID");
		lblUserID.setBounds(53, 51, 45, 13);
		contentPane.add(lblUserID);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setBounds(53, 96, 64, 13);
		contentPane.add(lblPassword);
		
		txtUserID = new JTextField();
		txtUserID.setBounds(152, 47, 171, 19);
		contentPane.add(txtUserID);
		txtUserID.setColumns(10);
		
		txtPassword = new JPasswordField();
		txtPassword.setBounds(152, 92, 171, 19);
		contentPane.add(txtPassword);
		
		JButton btnOK = new JButton("OK");
		btnOK.setBackground(new Color(135, 206, 250));
		btnOK.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String userID=txtUserID.getText();
				String password=txtPassword.getText();
				
				lDB=new logDB();
				Login log=lDB.get(userID);
				
				if((log!=null) && (userID.equals(log.getUserID())) && (password.equals(log.getPassword()))) {
					LoginInfo.userID=userID;
					MainUI mUI=new MainUI();
					mUI.setVisible(true);	
					setVisible(false);
				}else {
					JOptionPane.showMessageDialog(contentPane, "Invalid User ID or password");
				}
			}
		});
		btnOK.setBounds(53, 170, 115, 21);
		contentPane.add(btnOK);
		
		JButton btnCancel = new JButton("Cancel");
		btnCancel.setBackground(new Color(135, 206, 250));
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnCancel.setBounds(208, 170, 115, 21);
		contentPane.add(btnCancel);
		
		JLabel label4 = new JLabel("");
		Image img = new ImageIcon(this.getClass().getResource("/login2.png")).getImage();
		label4.setIcon(new ImageIcon (img));
		label4.setBounds(340, 19, 94, 96);
		contentPane.add(label4);
	}
}
