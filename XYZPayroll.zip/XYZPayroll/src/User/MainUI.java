package User;

import java.awt.BorderLayout;

import java.awt.EventQueue;

import javax.swing.AbstractButton;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.KeyStroke;
import java.awt.event.KeyEvent;
import java.awt.event.InputEvent;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Image;

import javax.swing.SwingConstants;


public class MainUI extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainUI frame = new MainUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MainUI() {
		setBackground(new Color(0, 204, 153));
		setTitle("Main");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 912, 543);
		setLocationRelativeTo(this);
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnFile = new JMenu(" File");
		menuBar.add(mnFile);
		
		
		JMenuItem mntmLogin = new JMenuItem("Login");
		mntmLogin.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_L, InputEvent.CTRL_MASK));
		mntmLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				LoginUI empUI=new LoginUI();
				empUI.setVisible(true);
			}
		});
		mnFile.add(mntmLogin);
		
		
		JMenuItem mntmEmployee = new JMenuItem("Employee");
		mntmEmployee.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_E, InputEvent.CTRL_MASK));
		mntmEmployee.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				EmployeeUI empUI=new EmployeeUI();
				empUI.setVisible(true);
			}
		});
		mnFile.add(mntmEmployee);
		

		JMenuItem mntmEnroll = new JMenuItem("Enroll");
		mntmEnroll.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_A, InputEvent.CTRL_MASK));
		mntmEnroll.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				EnrollUI empUI=new EnrollUI();
				empUI.setVisible(true);
			}
		});
		mnFile.add(mntmEnroll);
		
		
		
		JMenuItem mntmProject = new JMenuItem("Project");
		mntmProject.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_P, InputEvent.CTRL_MASK));
		mntmProject.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ProjectUI empUI=new ProjectUI();
				empUI.setVisible(true);
			}
		});
		mnFile.add(mntmProject);
		
		
		JMenuItem mntmSalarySlip = new JMenuItem("SalarySlip");
		mntmSalarySlip.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, InputEvent.CTRL_MASK));
		mntmSalarySlip.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SalarySlipUI empUI=new SalarySlipUI();
				empUI.setVisible(true);
			}
		});
		mnFile.add(mntmSalarySlip);
		
		
		
		JMenuItem mntmClose = new JMenuItem("Close");
		mntmClose.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_C, InputEvent.CTRL_MASK));
		mntmClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		
		JMenuItem mntmLogout = new JMenuItem("Logout");
		mntmLogout.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X, InputEvent.CTRL_MASK));
		mntmLogout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				LoginUI lui=new LoginUI();
				lui.setVisible(true);
				setVisible(false);
			}
		});
		mnFile.add(mntmLogout);
		mnFile.add(mntmClose);
		
		JMenu mnHelp = new JMenu("Help");
		menuBar.add(mnHelp);
		
		JMenuItem mntmNewLogin = new JMenuItem("New Login");
		mntmNewLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				NewLoginUI newLogUI=new NewLoginUI();
				newLogUI.setVisible(true);
			}
		});
		mnHelp.add(mntmNewLogin);
		
		JMenuItem mntmDelete = new JMenuItem("Delete Login");
		mntmDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DeleteLoginUI delUI=new DeleteLoginUI();
				delUI.setVisible(true);
			}
		});
		mnHelp.add(mntmDelete);
		
		JMenuItem mntmChangePassword = new JMenuItem("Change Password");
		mntmChangePassword.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ChangePwdUI cPWDUI=new ChangePwdUI();
				cPWDUI.setVisible(true);
			}
		});
		mnHelp.add(mntmChangePassword);
		
		
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 204, 51));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		JLabel lblNewLabel = new JLabel("XYZ  PAYROLL  SYSTEM");
		lblNewLabel.setForeground(new Color(0, 51, 153));
		lblNewLabel.setFont(new Font("Rosewood Std Regular", Font.PLAIN, 48));
		lblNewLabel.setBounds(224, 285, 489, 57);
		contentPane.add(lblNewLabel);
		
		JLabel label = new JLabel("");
		Image img = new ImageIcon(this.getClass().getResource("/xyzlogo.png")).getImage();
		label.setIcon(new ImageIcon (img));
		label.setBounds(315, 51, 244, 198);
		contentPane.add(label);
		
		
		
		
		
	}
}