package User;

public class LoginInfo {
  public static String userID;
}
